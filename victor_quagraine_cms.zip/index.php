<?php

header('Location: login/login_view.php');
exit;